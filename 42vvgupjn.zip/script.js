function updateClock() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    
    // Update analog clock
    const hourDeg = (hours % 12) * 30 + (minutes / 60) * 30; // 360 degrees / 12 hours
    const minuteDeg = (minutes * 6) + (seconds / 60) * 6; // 360 degrees / 60 minutes
    const secondDeg = seconds * 6; // 360 degrees / 60 seconds

    document.getElementById('hour').style.transform = rotate(${hourDeg}deg);
    document.getElementById('minute').style.transform = rotate(${minuteDeg}deg);
    document.getElementById('second').style.transform = rotate(${secondDeg}deg);

    // Update digital display
    const digitalDisplay = document.getElementById('digital-display');
    digitalDisplay.textContent = now.toLocaleTimeString();
}

// Update the clock every second
setInterval(updateClock, 1000);
updateClock(); // Initial call